# Scripts for Data Handling
  by Thomas Dokas
  
  <dokastho@umich.edu>
  
  for mbni
  
- [x] QC
- [x] Phase 1, 2 & 3 generalized script
## QC
